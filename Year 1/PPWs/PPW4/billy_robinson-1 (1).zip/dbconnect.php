<?php
 //database connection variables for a typical local development
 $servername = "localhost";
 $username = "root";
 $password = "";
 $database = "cycling"; //database name that you have already created that you want to connect to
 $port = 3306; // remember to change port to 3306 if you are using XAMPP
 ?>